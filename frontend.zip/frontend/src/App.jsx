import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import ProtectedRoute from "./auth/ProtectedRoute.jsx";

// Auth
import LoginSelection from "./pages/LoginSelection.jsx";
import LoginUser from "./pages/LoginUser.jsx";
import LoginAdmin from "./pages/LoginAdmin.jsx";
import SignupPage from "./pages/SignupPage.jsx";

// USER PAGES
import DashboardOverview from "./pages/user/DashboardOverview.jsx";
import LoansPage from "./pages/user/LoansPage.jsx";
import KycPage from "./pages/user/KycPage.jsx";
import WalletPage from "./pages/user/WalletPage.jsx";
import NotificationsPage from "./pages/user/NotificationsPage.jsx";
import SettingsPage from "./pages/user/SettingsPage.jsx";

// ADMIN PAGES
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import AdminLoans from "./pages/admin/AdminLoans.jsx";
import AdminKyc from "./pages/admin/AdminKyc.jsx";
import AdminUsers from "./pages/admin/AdminUsers.jsx";
import AdminUserView from "./pages/admin/AdminUserView.jsx";
import AdminPortfolio from "./pages/admin/AdminPortfolio.jsx";
import AdminLogs from "./pages/admin/AdminLogs.jsx";

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={<LoginSelection />} />
      <Route path="/user-login" element={<LoginUser />} />
      <Route path="/admin-login" element={<LoginAdmin />} />
      <Route path="/signup" element={<SignupPage />} />

      {/* USER ROUTES */}
      <Route
        path="/user/dashboard"
        element={
          <ProtectedRoute allowed={["user"]}>
            <DashboardOverview />
          </ProtectedRoute>
        }
      />

      <Route
        path="/user/loans"
        element={
          <ProtectedRoute allowed={["user"]}>
            <LoansPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/user/kyc"
        element={
          <ProtectedRoute allowed={["user"]}>
            <KycPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/user/wallet"
        element={
          <ProtectedRoute allowed={["user"]}>
            <WalletPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/user/notifications"
        element={
          <ProtectedRoute allowed={["user"]}>
            <NotificationsPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/user/settings"
        element={
          <ProtectedRoute allowed={["user"]}>
            <SettingsPage />
          </ProtectedRoute>
        }
      />

      {/* ADMIN ROUTES */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/loans"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminLoans />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/kyc"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminKyc />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/users"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminUsers />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/users/:userId"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminUserView />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/portfolio"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminPortfolio />
          </ProtectedRoute>
        }
      />

      <Route
        path="/admin/logs"
        element={
          <ProtectedRoute allowed={["admin"]}>
            <AdminLogs />
          </ProtectedRoute>
        }
      />

      {/* fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
