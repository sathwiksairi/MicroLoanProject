// frontend/src/pages/LoginAdmin.jsx
import React, { useState, useContext } from "react";
import API from "../api/axiosConfig";
import { useNavigate } from "react-router-dom";
import { basicAuthStyles } from "../styles/authStyles";
import { AuthContext } from "../auth/AuthContext.jsx";

export default function LoginAdmin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  const login = async () => {
    setMsg("");
    try {
      // use same /auth/login endpoint as original, then enforce role=admin
      const res = await API.post("/auth/login", { email, password });

      const user = res.data?.user ?? res.data;
      const role = user?.role;

      if (role !== "admin") {
        setMsg("Only admin/staff can login here.");
        return;
      }

      // store token + user in context/localStorage
      setUser(res.data);

      navigate("/admin");
    } catch (err) {
      console.error("Admin login error:", err?.response?.data || err.message);
      setMsg(err?.response?.data?.message || "Invalid admin credentials.");
    }
  };

  const styles = {
    ...basicAuthStyles,
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Admin Login</h2>

        <div style={styles.field}>
          <input
            style={styles.input}
            placeholder="Admin Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div style={styles.field}>
          <input
            type="password"
            style={styles.input}
            placeholder="Admin Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        {msg && <div style={styles.error}>{msg}</div>}

        <button style={styles.primaryBtn} onClick={login}>
          Login as Admin
        </button>

        <button style={styles.linkBtn} onClick={() => navigate("/")}>
          Back to Selection
        </button>
      </div>
    </div>
  );
}
