import React, { useState } from "react";
import API from "../api/axiosConfig";
import { useNavigate } from "react-router-dom";
import { basicAuthStyles } from "../styles/authStyles";

export default function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const [msg, setMsg] = useState("");

  const navigate = useNavigate();

  const signup = async () => {
    try {
      await API.post("/auth/user/register", {
        name,
        email,
        phone,
        password,
      });
      navigate("/user-login");
    } catch {
      setMsg("Signup failed. Try again.");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>Create Account</h2>

        <div style={styles.field}>
          <input
            style={styles.input}
            placeholder="Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div style={styles.field}>
          <input
            style={styles.input}
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div style={styles.field}>
          <input
            style={styles.input}
            placeholder="Phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>

        <div style={styles.field}>
          <input
            type="password"
            style={styles.input}
            placeholder="Create password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        {msg && <div style={styles.error}>{msg}</div>}

        <button style={styles.primaryBtn} onClick={signup}>
          Sign Up
        </button>

        <button
          style={styles.linkBtn}
          onClick={() => navigate("/user-login")}
        >
          Already have an account?
        </button>
      </div>
    </div>
  );
}

const styles = {
  ...basicAuthStyles,
};
