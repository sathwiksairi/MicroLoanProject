import React, { useContext, useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function NotificationsPage() {
  const { user, logout } = useContext(AuthContext);
  const [items, setItems] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const res = await API.get("/users/notifications");
        setItems(res.data || []);
      } catch (err) {
        console.error("Notifications fetch error:", err);
      }
    })();
  }, []);

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />
      <div className="page-layout">
        <Sidebar role="user" />
        <main className="page-content">
          <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 16 }}>
            Notifications
          </h1>

          <div className="card">
            {items.length === 0 ? (
              <p>No notifications yet.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {items.map((n) => (
                  <div
                    key={n._id}
                    className="card"
                    style={{
                      boxShadow: "none",
                      borderColor: "#e5e7eb",
                      padding: 12,
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <div>
                        <div
                          style={{
                            fontSize: 14,
                            fontWeight: 600,
                            marginBottom: 4,
                          }}
                        >
                          {n.title || "Notification"}
                        </div>
                        <div
                          style={{
                            fontSize: 13,
                            color: "#4b5563",
                          }}
                        >
                          {n.message}
                        </div>
                      </div>
                      <span className="badge badge-muted">
                        {n.createdAt
                          ? new Date(n.createdAt).toLocaleString()
                          : ""}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
