import React, { useContext, useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function WalletPage() {
  const { user, logout } = useContext(AuthContext);
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const res = await API.get("/users/me");
        setBalance(res.data?.walletBalance || 0);
        setTransactions(res.data?.walletHistory || []);
      } catch (err) {
        console.error("Wallet fetch error:", err);
      }
    })();
  }, []);

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />
      <div className="page-layout">
        <Sidebar role="user" />
        <main className="page-content">
          <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 16 }}>
            Wallet
          </h1>

          {/* Wallet card */}
          <div
            className="card"
            style={{
              background:
                "linear-gradient(135deg,#0f172a,#1d4ed8,#0ea5e9 80%)",
              color: "#e5e7eb",
              marginBottom: 20,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontSize: 13, opacity: 0.8 }}>Current Balance</div>
                <div style={{ fontSize: 28, fontWeight: 700 }}>
                  ₹{balance.toFixed(2)}
                </div>
                <div style={{ fontSize: 11, opacity: 0.75, marginTop: 4 }}>
                  Linked to your MicroLoan student account
                </div>
              </div>
            </div>
          </div>

          {/* Transactions */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">Recent Wallet Activity</div>
            </div>
            {transactions.length === 0 ? (
              <p>No wallet transactions yet.</p>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Note</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((t, i) => (
                    <tr key={i}>
                      <td>
                        <span
                          className={
                            t.type === "credit"
                              ? "badge badge-success"
                              : "badge badge-danger"
                          }
                        >
                          {t.type}
                        </span>
                      </td>
                      <td>₹{t.amount}</td>
                      <td>{t.note || "-"}</td>
                      <td>
                        {t.date
                          ? new Date(t.date).toLocaleString()
                          : "-"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
