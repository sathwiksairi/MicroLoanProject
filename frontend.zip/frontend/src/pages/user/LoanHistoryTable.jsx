// frontend/src/pages/user/LoanHistoryTable.jsx
import React from "react";

const fmt = (d) => (d ? new Date(d).toLocaleDateString("en-GB") : "-");

const statusClass = (status) => {
  switch (status) {
    case "approved":
      return "badge badge-approved";
    case "repaid":
      return "badge badge-repaid";
    case "rejected":
      return "badge badge-rejected";
    default:
      return "badge badge-pending";
  }
};

export default function LoanHistoryTable({ loans = [], loading, onRepay }) {
  if (loading) return <p>Loading loans...</p>;
  if (!loans.length) return <p>No loans found.</p>;

  return (
    <table className="table">
      <thead>
        <tr>
          <th>Amount</th>
          <th>Tenure</th>
          <th>Status</th>
          <th>Requested</th>
          <th>Repay by</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {loans.map((l) => (
          <tr key={l._id}>
            <td>₹{l.amount}</td>
            <td>{l.tenureDays}d</td>
            <td>
              <span className={statusClass(l.status)}>{l.status}</span>
            </td>
            <td>{fmt(l.createdAt)}</td>
            <td>{fmt(l.repayBy)}</td>
            <td>
              {l.status === "approved" ? (
                <button
                  className="btn btn-primary"
                  style={{ padding: "3px 10px", fontSize: 12 }}
                  onClick={() => onRepay && onRepay(l._id)}
                >
                  Repay
                </button>
              ) : (
                "-"
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
