import React, { useEffect, useState, useContext } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function DashboardOverview() {
  const { user, logout } = useContext(AuthContext);

  const [loans, setLoans] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const res = await API.get("/loans/my-loans");
        setLoans(res.data || []);
      } catch (err) {
        console.error("Loan fetch error:", err);
      }
    })();
  }, []);

  // -------------------------------
  // 🔥 FINTECH BALANCE CALCULATIONS
  // -------------------------------
  const totalBorrowed = loans
    .filter((l) => l.status === "approved" || l.status === "repaid")
    .reduce((sum, loan) => sum + loan.amount, 0);

  const totalRepaid = loans
    .filter((l) => l.status === "repaid")
    .reduce((sum, loan) => sum + loan.amount, 0);

  const outstandingBalance = totalBorrowed - totalRepaid;

  const activeLoans = loans.filter((l) => l.status === "approved").length;
  const pendingLoans = loans.filter((l) => l.status === "pending").length;

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />

      <div className="page-layout">
        <Sidebar role="user" />

        <main className="page-content">
          {/* ---------------------------------- */}
          {/* 🔥 Premium Welcome Banner */}
          {/* ---------------------------------- */}
          <div
            style={{
              background: "linear-gradient(90deg, #2563eb, #14b8a6)",
              padding: "28px",
              borderRadius: "18px",
              color: "white",
              marginBottom: "26px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              boxShadow: "0 8px 24px rgba(37, 99, 235, 0.25)",
            }}
          >
            <div>
              <div style={{ fontSize: 22, fontWeight: 600 }}>
                Welcome back, {user?.name?.split(" ")[0]} 👋
              </div>
              <div style={{ opacity: 0.9 }}>
                Your fintech account dashboard.
              </div>
            </div>

            {/* Balance Box */}
            <div
              style={{
                background: "rgba(255,255,255,0.15)",
                padding: "16px 22px",
                borderRadius: "14px",
                backdropFilter: "blur(6px)",
                minWidth: "260px",
              }}
            >
              <div style={{ fontSize: 14, opacity: 0.85 }}>Outstanding Balance</div>
              <div style={{ fontSize: 26, fontWeight: 700, marginBottom: 6 }}>
                ₹{outstandingBalance}
              </div>

              <div
                style={{
                  fontSize: 13,
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <span>Total Borrowed</span>
                <b>₹{totalBorrowed}</b>
              </div>

              <div
                style={{
                  fontSize: 13,
                  display: "flex",
                  justifyContent: "space-between",
                  marginTop: 4,
                }}
              >
                <span>Total Repaid</span>
                <b>₹{totalRepaid}</b>
              </div>
            </div>
          </div>

          {/* -------------------------- */}
          {/* Stats Cards */}
          {/* -------------------------- */}
          <div className="four-card-grid">
            <div className="stat-card">
              <div className="stat-title">Total Loans</div>
              <div className="stat-value">{loans.length}</div>
              <div className="stat-subtitle">All loans requested so far</div>
            </div>

            <div className="stat-card">
              <div className="stat-title">Active Loans</div>
              <div className="stat-value">{activeLoans}</div>
              <div className="stat-subtitle">Currently running loans</div>
            </div>

            <div className="stat-card">
              <div className="stat-title">Pending Approvals</div>
              <div className="stat-value">{pendingLoans}</div>
              <div className="stat-subtitle">Awaiting admin review</div>
            </div>

            <div className="stat-card">
              <div className="stat-title">Total Borrowed</div>
              <div className="stat-value">₹{totalBorrowed}</div>
              <div className="stat-subtitle">Approved + repaid loans</div>
            </div>
          </div>

          {/* -------------------------- */}
          {/* Recent Loans Table */}
          {/* -------------------------- */}
          <div className="card" style={{ padding: 20, marginTop: 26 }}>
            <div className="card-title">Recent Loans</div>
            <div className="card-subtitle">A quick view of your latest activity</div>

            <table className="clean-table" style={{ marginTop: 18 }}>
              <thead>
                <tr>
                  <th>Amount</th>
                  <th>Tenure</th>
                  <th>Status</th>
                  <th>Requested</th>
                  <th>Repay By</th>
                </tr>
              </thead>
              <tbody>
                {loans.slice(0, 5).map((loan) => (
                  <tr key={loan._id}>
                    <td>₹{loan.amount}</td>
                    <td>{loan.tenure}</td>
                    <td>
                      <span className={`status-pill ${loan.status}`}>
                        {loan.status}
                      </span>
                    </td>
                    <td>{loan.requestDate?.slice(0, 10)}</td>
                    <td>{loan.repayDate || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
}
