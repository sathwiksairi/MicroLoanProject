// src/pages/user/KycPage.jsx
import React, { useContext, useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig.js";    // ✅ FIXED
import { AuthContext } from "../../auth/AuthContext.jsx";

const steps = [
  { id: 1, label: "Personal Details" },
  { id: 2, label: "Identity Verification" },
  { id: 3, label: "Address" },
  { id: 4, label: "Review & Submit" },
];

export default function KycPage() {
  const { user, logout } = useContext(AuthContext);

  const [kycStatus, setKycStatus] = useState("not_submitted");
  const [currentStep, setCurrentStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");

  // Step 1 – Personal
  const [personal, setPersonal] = useState({
    fullName: "",
    dob: "",
    gender: "",
    phone: "",
    email: "",
  });

  // Step 2 – Identity (ALL REQUIRED)
  const [identity, setIdentity] = useState({
    aadhaar: "",
    pan: "",
    passport: "",
  });

  // Step 3 – Address
  const [address, setAddress] = useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    pincode: "",
    country: "India",
  });

  useEffect(() => {
    (async () => {
      try {
        const res = await API.get("/users/me");
        setKycStatus(res.data?.kyc?.status || "not_submitted");

        setPersonal((prev) => ({
          ...prev,
          fullName: res.data?.name || "",
          email: res.data?.email || "",
          phone: res.data?.phone || "",
        }));
      } catch (err) {
        console.error("KYC fetch error:", err);
      }
    })();
  }, []);

  const prettyStatus =
    kycStatus === "approved"
      ? "KYC Verified"
      : kycStatus === "pending"
      ? "Under Review"
      : "Not Submitted";

  const badgeClass =
    kycStatus === "approved"
      ? "badge badge-success"
      : kycStatus === "pending"
      ? "badge badge-warning"
      : "badge badge-muted";

  const update = (setter) => (field, value) =>
    setter((prev) => ({ ...prev, [field]: value }));

  const updatePersonal = update(setPersonal);
  const updateIdentity = update(setIdentity);
  const updateAddress = update(setAddress);

  // VALIDATION
  const isStepValid = () => {
    if (currentStep === 1)
      return (
        personal.fullName &&
        personal.dob &&
        personal.gender &&
        personal.phone
      );

    if (currentStep === 2)
      return (
        identity.aadhaar.length >= 6 &&
        identity.pan.length >= 6 &&
        identity.passport.length >= 6
      );

    if (currentStep === 3)
      return (
        address.line1 &&
        address.city &&
        address.state &&
        address.pincode &&
        address.country
      );

    return true;
  };

  const handleNext = () => {
    if (currentStep < 4) setCurrentStep((s) => s + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep((s) => s - 1);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setMessage("");

    try {
      await API.post("/users/kyc", {
        personal,
        identity,
        address,
      });

      setKycStatus("pending");
      setMessage("KYC submitted successfully. Our team will review it shortly.");
      setCurrentStep(1);
    } catch (err) {
      console.error("Error submitting KYC:", err);
      setMessage("Failed to submit KYC. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />
      <div className="page-layout">
        <Sidebar role="user" />

        <main className="page-content">
          <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 14 }}>
            KYC Verification
          </h1>

          {/* KYC STATUS */}
          <div
            className="card"
            style={{
              marginBottom: 20,
              padding: "16px 20px",
              display: "flex",
              justifyContent: "space-between",
              background:
                "linear-gradient(135deg, rgba(59,130,246,0.06), rgba(34,197,94,0.03))",
            }}
          >
            <div>
              <div style={{ fontWeight: 600 }}>KYC Status</div>
              <div style={{ fontSize: 13, color: "#6b7280" }}>
                Complete your KYC for faster withdrawals, higher limits, and full access.
              </div>
            </div>
            <span className={badgeClass}>{prettyStatus}</span>
          </div>

          {/* CARD */}
          <div className="card" style={{ padding: 22 }}>
            <StepIndicator currentStep={currentStep} />

            <div style={{ marginTop: 24 }}>
              {currentStep === 1 && (
                <StepPersonal personal={personal} update={updatePersonal} />
              )}

              {currentStep === 2 && (
                <StepIdentity identity={identity} update={updateIdentity} />
              )}

              {currentStep === 3 && (
                <StepAddress address={address} update={updateAddress} />
              )}

              {currentStep === 4 && (
                <StepReview personal={personal} identity={identity} address={address} />
              )}
            </div>

            {/* BUTTONS */}
            <div
              style={{
                marginTop: 28,
                display: "flex",
                justifyContent: "flex-end",
                gap: 10,
              }}
            >
              {currentStep > 1 && (
                <button className="btn btn-ghost" style={ghostBtn} onClick={handleBack}>
                  Back
                </button>
              )}

              {currentStep < 4 && (
                <button
                  className="btn btn-ghost"
                  style={ghostBtn}
                  disabled={!isStepValid()}
                  onClick={handleNext}
                >
                  Next
                </button>
              )}

              {currentStep === 4 && (
                <button
                  className="btn btn-ghost"
                  style={ghostBtn}
                  onClick={handleSubmit}
                  disabled={submitting}
                >
                  {submitting ? "Submitting..." : "Submit"}
                </button>
              )}
            </div>

            {message && (
              <div style={{ marginTop: 16, fontSize: 13, color: "#4b5563" }}>
                {message}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

// GHOST BUTTON STYLE
const ghostBtn = {
  padding: "8px 18px",
  border: "1px solid #cbd5e1",
  background: "#ffffff",
  borderRadius: 8,
  fontSize: 14,
  cursor: "pointer",
  transition: "0.2s",
};

// STEP INDICATOR
function StepIndicator({ currentStep }) {
  return (
    <div
      style={{
        display: "flex",
        gap: 12,
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      {steps.map((step, i) => {
        const active = currentStep === step.id;
        const completed = currentStep > step.id;

        return (
          <div key={step.id} style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div
                style={{
                  width: 26,
                  height: 26,
                  borderRadius: "50%",
                  background: active || completed ? "#2563eb" : "#e5e7eb",
                  color: active || completed ? "white" : "#6b7280",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {completed ? "✓" : step.id}
              </div>

              <div
                style={{
                  fontWeight: active ? 700 : 500,
                  color: active ? "#111827" : "#6b7280",
                  fontSize: 13,
                }}
              >
                {step.label}
              </div>
            </div>

            {i < steps.length - 1 && (
              <div
                style={{
                  marginTop: 6,
                  height: 2,
                  background: completed ? "#2563eb" : "#e5e7eb",
                }}
              ></div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// FIELD COMPONENT
function Field({ label, value, onChange, placeholder }) {
  return (
    <div>
      <label style={{ fontSize: 13, color: "#6b7280" }}>{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%",
          padding: "10px 12px",
          borderRadius: 8,
          border: "1px solid #d1d5db",
          background: "#f9fafb",
          fontSize: 14,
          marginTop: 4,
        }}
      />
    </div>
  );
}

// STEP 1 — PERSONAL
function StepPersonal({ personal, update }) {
  return (
    <div>
      <h2 className="step-title">Personal Details</h2>
      <p className="step-desc">Please provide your basic verification details.</p>

      <div className="grid-2col">
        <Field label="Full Name" value={personal.fullName} onChange={(v) => update("fullName", v)} />
        <Field label="Date of Birth" value={personal.dob} onChange={(v) => update("dob", v)} />
        <Field label="Gender" value={personal.gender} onChange={(v) => update("gender", v)} />
        <Field label="Phone" value={personal.phone} onChange={(v) => update("phone", v)} />
        <Field label="Email" value={personal.email} onChange={(v) => update("email", v)} />
      </div>
    </div>
  );
}

// STEP 2 — IDENTITY (UPDATED)
function StepIdentity({ identity, update }) {
  return (
    <div>
      <h2 className="step-title">Identity Verification</h2>
      <p className="step-desc">Enter all required government-issued identification numbers.</p>

      <div className="grid-2col">
        <Field
          label="Aadhaar Number"
          value={identity.aadhaar}
          onChange={(v) => update("aadhaar", v)}
          placeholder="Enter Aadhaar number"
        />

        <Field
          label="PAN Number"
          value={identity.pan}
          onChange={(v) => update("pan", v)}
          placeholder="Enter PAN number"
        />

        <Field
          label="Passport Number"
          value={identity.passport}
          onChange={(v) => update("passport", v)}
          placeholder="Enter Passport number"
        />
      </div>
    </div>
  );
}

// STEP 3 — ADDRESS
function StepAddress({ address, update }) {
  return (
    <div>
      <h2 className="step-title">Address</h2>
      <p className="step-desc">Enter your permanent residential address.</p>

      <div className="grid-2col">
        <Field label="Address Line 1" value={address.line1} onChange={(v) => update("line1", v)} />
        <Field label="Address Line 2" value={address.line2} onChange={(v) => update("line2", v)} />
        <Field label="City" value={address.city} onChange={(v) => update("city", v)} />
        <Field label="State" value={address.state} onChange={(v) => update("state", v)} />
        <Field label="Pincode" value={address.pincode} onChange={(v) => update("pincode", v)} />
        <Field label="Country" value={address.country} onChange={(v) => update("country", v)} />
      </div>
    </div>
  );
}

// STEP 4 — REVIEW
function StepReview({ personal, identity, address }) {
  const Item = ({ label, value }) => (
    <div style={{ marginBottom: 6 }}>
      <div style={{ fontSize: 12, color: "#6b7280" }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 500 }}>{value || "—"}</div>
    </div>
  );

  return (
    <div>
      <h2 className="step-title">Review & Submit</h2>
      <p className="step-desc">Review all details carefully before submitting.</p>

      <div className="grid-3col">
        {/* PERSONAL */}
        <div className="review-card">
          <div className="review-title">Personal Details</div>
          <Item label="Full Name" value={personal.fullName} />
          <Item label="DOB" value={personal.dob} />
          <Item label="Gender" value={personal.gender} />
          <Item label="Phone" value={personal.phone} />
          <Item label="Email" value={personal.email} />
        </div>

        {/* IDENTITY */}
        <div className="review-card">
          <div className="review-title">Identity Verification</div>
          <Item label="Aadhaar Number" value={identity.aadhaar} />
          <Item label="PAN Number" value={identity.pan} />
          <Item label="Passport Number" value={identity.passport} />
        </div>

        {/* ADDRESS */}
        <div className="review-card">
          <div className="review-title">Address</div>
          <Item label="Line 1" value={address.line1} />
          <Item label="Line 2" value={address.line2} />
          <Item label="City" value={address.city} />
          <Item label="State" value={address.state} />
          <Item label="Pincode" value={address.pincode} />
          <Item label="Country" value={address.country} />
        </div>
      </div>
    </div>
  );
}
