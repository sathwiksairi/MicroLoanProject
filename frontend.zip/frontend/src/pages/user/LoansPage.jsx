import React, { useContext, useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig.js";   // ✅ FIXED
import LoanRequestModal from "./LoanRequestModal.jsx";
import LoanHistoryTable from "./LoanHistoryTable.jsx";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function LoansPage() {
  const { user, logout } = useContext(AuthContext);
  const [openModal, setOpenModal] = useState(false);
  const [loans, setLoans] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await API.get("/loans/my-loans");
      setLoans(res.data || []);
    } catch (err) {
      console.error("Failed to load loans:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleRepay = async (id) => {
    if (!window.confirm("Repay this loan now?")) return;
    try {
      await API.patch(`/loans/${id}/repay`);
      await load();
    } catch (err) {
      alert(err.response?.data?.message || "Failed to repay loan");
    }
  };

  return (
    <div>
      <Navbar user={user} onLogout={logout} />

      <div style={{ display: "flex", gap: 24, padding: "20px" }}>
        <aside style={{ width: 320 }}>
          <Sidebar />
        </aside>

        <main style={{ flex: 1 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <div>
              <h2 style={{ fontSize: 22, fontWeight: 700 }}>Your Loans</h2>
              <p style={{ fontSize: 14, color: "#6b7280" }}>
                Track all your loan requests and repayments in one place.
              </p>
            </div>

            <button
              className="btn btn-primary"
              style={{ padding: "6px 14px", fontSize: 13, fontWeight: 600 }}
              onClick={() => setOpenModal(true)}
            >
              Request Loan
            </button>
          </div>

          <div className="table-wrapper">
            <LoanHistoryTable
              loans={loans}
              loading={loading}
              onRepay={handleRepay}
            />
          </div>
        </main>
      </div>

      <LoanRequestModal
        open={openModal}
        onClose={() => {
          setOpenModal(false);
          load();
        }}
      />
    </div>
  );
}
