import React, { useContext } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function SettingsPage() {
  const { user, logout } = useContext(AuthContext);

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />
      <div className="page-layout">
        <Sidebar role="user" />
        <main className="page-content">
          <h1 style={{ fontSize: 22, fontWeight: 600, marginBottom: 16 }}>
            Settings
          </h1>

          <div
            className="card"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
              gap: 16,
            }}
          >
            <div className="card" style={{ boxShadow: "none" }}>
              <div className="card-title">Profile</div>
              <div className="card-subtitle">
                Basic details linked to your MicroLoan account.
              </div>
              <div style={{ marginTop: 10, fontSize: 14 }}>
                <div>
                  <strong>Name:</strong> {user?.name}
                </div>
                <div>
                  <strong>Email:</strong> {user?.email}
                </div>
                <div>
                  <strong>Role:</strong>{" "}
                  {user?.role ? user.role.toUpperCase() : "USER"}
                </div>
              </div>
            </div>

            <div className="card" style={{ boxShadow: "none" }}>
              <div className="card-title">Security</div>
              <div className="card-subtitle">
                Manage login and account protection.
              </div>
              <button
                className="btn btn-secondary"
                style={{ marginTop: 10 }}
                onClick={logout}
              >
                Logout from all devices
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
