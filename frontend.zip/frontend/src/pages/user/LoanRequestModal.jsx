import React, { useState } from "react";
import Modal from "../../components/modal.jsx";
import API from "../../api/axiosConfig";

export default function LoanRequestModal({ open, onClose, onSuccess }) {
  const [amount, setAmount] = useState("");
  const [tenure, setTenure] = useState("");
  const [status, setStatus] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    if (!amount || !tenure) {
      setStatus("Please enter both amount and tenure.");
      return;
    }
    try {
      await API.post("/loans/request", {
        amount: Number(amount),
        tenureDays: Number(tenure),
      });
      setStatus("Request submitted for review.");
      setAmount("");
      setTenure("");
      onClose();
      onSuccess && onSuccess();
    } catch (err) {
      setStatus(
        err.response?.data?.message || "Loan request failed. Try again."
      );
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Request a Loan">
      <form onSubmit={submit} className="form">
        <label>Amount (₹)</label>
        <input
          type="number"
          min="1"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="e.g. 1500"
        />

        <label>Tenure (days)</label>
        <input
          type="number"
          min="1"
          value={tenure}
          onChange={(e) => setTenure(e.target.value)}
          placeholder="e.g. 10"
        />

        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <button className="btn btn-primary" type="submit">
            Submit Request
          </button>
          <button
            className="btn btn-ghost"
            type="button"
            onClick={onClose}
          >
            Cancel
          </button>
        </div>

        {status && (
          <div className="status" style={{ marginTop: 6 }}>
            {status}
          </div>
        )}
      </form>
    </Modal>
  );
}
