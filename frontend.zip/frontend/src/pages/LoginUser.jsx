// frontend/src/pages/LoginUser.jsx
import React, { useState, useContext } from "react";
import API from "../api/axiosConfig";
import { useNavigate } from "react-router-dom";
import { basicAuthStyles } from "../styles/authStyles";
import { AuthContext } from "../auth/AuthContext.jsx";

export default function LoginUser() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  const navigate = useNavigate();
  const { setUser } = useContext(AuthContext);

  const login = async () => {
    setMsg("");
    try {
      // IMPORTANT: use the original working endpoint
      const res = await API.post("/auth/login", { email, password });

      // This works with AuthContext.setUser which accepts { token, user } or just user
      setUser(res.data);

      const role = res.data?.user?.role ?? res.data?.role;
      if (role === "admin") {
        navigate("/admin");
      } else {
        // match your current user dashboard route
        navigate("/user/dashboard");
      }
    } catch (err) {
      console.error("User login error:", err?.response?.data || err.message);
      setMsg(err?.response?.data?.message || "Invalid email or password.");
    }
  };

  const styles = {
    ...basicAuthStyles,
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>User Login</h2>

        <div style={styles.field}>
          <input
            style={styles.input}
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div style={styles.field}>
          <input
            type="password"
            style={styles.input}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        {msg && <div style={styles.error}>{msg}</div>}

        <button style={styles.primaryBtn} onClick={login}>
          Login
        </button>

        <button style={styles.linkBtn} onClick={() => navigate("/signup")}>
          Don't have an account?
        </button>
      </div>
    </div>
  );
}
