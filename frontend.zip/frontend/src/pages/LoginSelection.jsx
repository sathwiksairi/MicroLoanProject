import React from "react";
import { useNavigate } from "react-router-dom";

export default function LoginSelection() {
  const navigate = useNavigate();

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>Welcome to MicroLoan</h1>
        <p style={styles.subtitle}>Choose how you want to continue</p>

        <div style={styles.buttons}>
          <button style={styles.primaryBtn} onClick={() => navigate("/user-login")}>
            Login as User
          </button>

          <button style={styles.secondaryBtn} onClick={() => navigate("/admin-login")}>
            Login as Admin
          </button>

          <button style={styles.linkBtn} onClick={() => navigate("/signup")}>
            Create a new account →
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background:
      "linear-gradient(135deg, #2563EB, #1E3A8A, #0EA5E9, #4338CA)",
    backgroundSize: "300% 300%",
    animation: "gradient 12s ease infinite",
  },

  card: {
    width: "90%",
    maxWidth: "420px",
    padding: "35px",
    borderRadius: "18px",
    background: "rgba(255,255,255,0.15)",
    backdropFilter: "blur(12px)",
    boxShadow: "0 8px 32px rgba(0,0,0,0.25)",
    textAlign: "center",
  },

  title: {
    fontSize: "28px",
    color: "white",
    marginBottom: "10px",
    fontWeight: 700,
  },

  subtitle: {
    color: "#e2e8f0",
    marginBottom: "30px",
    fontSize: "14px",
  },

  buttons: {
    display: "flex",
    flexDirection: "column",
    gap: "14px",
  },

  primaryBtn: {
    padding: "12px",
    borderRadius: "10px",
    background: "#2563EB",
    color: "white",
    border: "none",
    fontSize: "15px",
    fontWeight: 600,
    cursor: "pointer",
  },

  secondaryBtn: {
    padding: "12px",
    borderRadius: "10px",
    background: "#1E3A8A",
    color: "white",
    border: "none",
    fontSize: "15px",
    fontWeight: 600,
    cursor: "pointer",
  },

  linkBtn: {
    marginTop: "6px",
    background: "transparent",
    border: "none",
    color: "#dbeafe",
    textDecoration: "underline",
    cursor: "pointer",
    fontSize: "14px",
  },
};
