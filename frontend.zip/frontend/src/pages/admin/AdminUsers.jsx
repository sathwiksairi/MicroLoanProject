import React, { useContext, useEffect, useState } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function AdminUsers() {
  const { user, logout } = useContext(AuthContext);
  const [users, setUsers] = useState([]);

  const load = async () => {
    try {
      const res = await API.get("/admin/users");
      setUsers(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const changeStatus = async (userId, accountStatus) => {
    if (!window.confirm(`Set account to ${accountStatus}?`)) return;
    try {
      await API.patch(`/admin/users/${userId}/status`, { accountStatus });
      load();
    } catch (err) {
      alert(err.response?.data?.message || "Failed to update status");
    }
  };

  const changeRole = async (userId, role) => {
    if (!window.confirm(`Change role to ${role}?`)) return;
    try {
      await API.patch(`/admin/users/${userId}/role`, { role });
      load();
    } catch (err) {
      alert(err.response?.data?.message || "Failed to update role");
    }
  };

  return (
    <div>
      <Navbar user={user} onLogout={logout} />
      <div style={{ display: "flex", gap: 24, padding: "20px" }}>
        <aside style={{ width: 320 }}>
          <Sidebar role="admin" />
        </aside>

        <main style={{ flex: 1 }}>
          <div className="card">
            <h2>Users Management</h2>
            <p className="muted">
              View, authorise, freeze or promote users — like a real bank admin.
            </p>

            <div style={{ overflowX: "auto" }}>
              <table className="table">
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Role</th>
                    <th>KYC</th>
                    <th>Account</th>
                    <th>Wallet</th>
                    <th>Last login</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u._id}>
                      <td>
                        <strong>{u.name}</strong>
                        <br />
                        <small>{u.email}</small>
                      </td>
                      <td>{u.role}</td>
                      <td>{u.kyc?.status}</td>
                      <td>{u.accountStatus}</td>
                      <td>{u.kyc?.cryptoAddress || "-"}</td>
                      <td>
                        {u.lastLoginAt
                          ? new Date(u.lastLoginAt).toLocaleString()
                          : "-"}
                      </td>
                      <td>
                        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                          {/* Role actions */}
                          {u.role === "user" ? (
                            <button
                              className="secondary"
                              onClick={() => changeRole(u._id, "admin")}
                            >
                              Make admin
                            </button>
                          ) : (
                            <button
                              className="secondary"
                              onClick={() => changeRole(u._id, "user")}
                            >
                              Make user
                            </button>
                          )}

                          {/* Account status actions */}
                          {u.accountStatus !== "active" && (
                            <button
                              className="primary"
                              onClick={() => changeStatus(u._id, "active")}
                            >
                              Set active
                            </button>
                          )}
                          {u.accountStatus !== "frozen" && (
                            <button
                              onClick={() => changeStatus(u._id, "frozen")}
                            >
                              Freeze
                            </button>
                          )}
                          {u.accountStatus !== "blocked" && (
                            <button
                              className="danger"
                              onClick={() => changeStatus(u._id, "blocked")}
                            >
                              Block
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {users.length === 0 && (
                    <tr>
                      <td colSpan="7">No users yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}