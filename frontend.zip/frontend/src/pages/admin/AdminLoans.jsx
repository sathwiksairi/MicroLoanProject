// frontend/src/pages/admin/AdminLoans.jsx
import React, { useEffect, useState, useContext } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

const fmtDate = (d) => (d ? new Date(d).toLocaleDateString() : "-");

export default function AdminLoans() {
  const { user, logout } = useContext(AuthContext);
  const [loans, setLoans] = useState([]);

  const load = async () => {
    try {
      const res = await API.get("/admin/loans");
      setLoans(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const takeAction = async (id, action) => {
    if (!window.confirm(`Are you sure to ${action} this loan?`)) return;
    try {
      await API.patch(`/admin/loans/${id}/${action}`, {
        remarks: `${action} by admin`,
      });
      load();
    } catch (err) {
      alert(err.response?.data?.message || "Failed");
    }
  };

  return (
    <div>
      <Navbar user={user} onLogout={logout} />
      <div style={{ display: "flex", gap: 24, padding: "20px" }}>
        <aside style={{ width: 320 }}>
          <Sidebar role="admin" />
        </aside>
        <main style={{ flex: 1 }}>
          <div className="card">
            <h2>All Loans</h2>
            <table className="table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Amt</th>
                  <th>Tenure</th>
                  <th>Status</th>
                  <th>Requested</th>
                  <th>Repay by</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {loans.map((l) => (
                  <tr key={l._id}>
                    <td>
                      {l.user?.name}
                      <br />
                      <small>{l.user?.email}</small>
                    </td>
                    <td>₹{l.amount}</td>
                    <td>{l.tenureDays}d</td>
                    <td>{l.status}</td>
                    <td>{fmtDate(l.createdAt)}</td>
                    <td>{fmtDate(l.repayBy)}</td>
                    <td>
                      {l.status === "pending" ? (
                        <>
                          <button
                            onClick={() => takeAction(l._id, "approve")}
                          >
                            Approve
                          </button>
                          <button
                            className="danger"
                            onClick={() => takeAction(l._id, "reject")}
                          >
                            Decline
                          </button>
                        </>
                      ) : (
                        "-"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
}
