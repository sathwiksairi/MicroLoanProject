import React, { useEffect, useState, useContext } from "react";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import API from "../../api/axiosConfig";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function AdminKyc() {
  const { user, logout } = useContext(AuthContext);
  const [pending, setPending] = useState([]);

  const load = async () => {
    try {
      const res = await API.get("/admin/kyc-pending");
      setPending(res.data);
    } catch (err) { console.error(err); }
  };

  useEffect(()=>{ load(); }, []);

  const update = async (userId, status) => {
    if (!window.confirm(`Mark as ${status}?`)) return;
    try {
      await API.patch(`/admin/users/${userId}/kyc`, { status });
      load();
    } catch (err) { alert("Failed"); }
  };

  return (
    <div>
      <Navbar user={user} onLogout={logout} />
      <div style={{display:"flex", gap:24, padding:"20px"}}>
        <aside style={{width:320}}><Sidebar role="admin"/></aside>
        <main style={{flex:1}}>
          <div className="card">
            <h2>KYC Pending</h2>
            {pending.length===0 ? <p>No pending.</p> : pending.map(u=>(
              <div key={u._id} style={{marginBottom:12}}>
                <strong>{u.name}</strong> – {u.email}
                <p>Exchange: {u.cryptoExchange} • Network: {u.walletNetwork}</p>
                <div style={{display:"flex", gap:8}}>
                  <button className="success" onClick={()=>update(u._id,"verified")}>Verify</button>
                  <button className="danger" onClick={()=>update(u._id,"rejected")}>Reject</button>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
