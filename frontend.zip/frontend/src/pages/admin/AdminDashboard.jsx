// src/pages/admin/AdminDashboard.jsx
import React, { useEffect, useState, useContext } from "react";
import API from "../../api/axiosConfig";
import Navbar from "../../components/Navbar.jsx";
import Sidebar from "../../components/Sidebar.jsx";
import { AuthContext } from "../../auth/AuthContext.jsx";

export default function AdminDashboard() {
  const { user, logout } = useContext(AuthContext);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await API.get("/admin/summary");
        setSummary(res.data);
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  if (!summary) return <div style={{ padding: 30 }}>Loading…</div>;

  const totalUsers = summary.totalUsers ?? 0;
  const kycPending = summary.kycPending ?? 0;
  const loansPending = summary.loansPending ?? 0;
  const activeLoans = summary.activeLoans ?? 0;

  const recentUsers = Array.isArray(summary.recentUsers)
    ? summary.recentUsers
    : [];

  return (
    <div className="app-shell">
      <Navbar user={user} onLogout={logout} />
      <div className="page-layout">
        <Sidebar role="admin" />
        <main className="page-content">
          <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 16 }}>
            Dashboard Overview
          </h1>

          <div className="stat-grid">
            <div className="stat-card">
              <div className="stat-label">Total Users</div>
              <div className="stat-value">{totalUsers}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">KYC Pending</div>
              <div className="stat-value">{kycPending}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Loans Pending</div>
              <div className="stat-value">{loansPending}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Active Loans</div>
              <div className="stat-value">{activeLoans}</div>
            </div>
          </div>

          <div className="card" style={{ marginTop: 20 }}>
            <div className="card-header">
              <div>
                <div className="card-title">Recently Registered Users</div>
                <div className="card-subtitle">
                  Latest signups on the platform
                </div>
              </div>
            </div>

            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {recentUsers.length ? (
                  recentUsers.map((u) => (
                    <tr key={u._id}>
                      <td>{u.name}</td>
                      <td>{u.email}</td>
                      <td>
                        {u.createdAt
                          ? new Date(u.createdAt).toLocaleString()
                          : "-"}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3}>No recent users.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
}
