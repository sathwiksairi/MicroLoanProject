import React, { useEffect, useState } from "react";
import API from "../../api/axiosConfig";
import Sidebar from "../../components/Sidebar.jsx";
import Navbar from "../../components/Navbar.jsx";

// Charts
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  LineElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  PointElement,
} from "chart.js";

import { Pie, Bar, Line } from "react-chartjs-2";

ChartJS.register(
  ArcElement,
  BarElement,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

export default function AdminPortfolio() {
  const [portfolio, setPortfolio] = useState(null);

  const load = async () => {
    try {
      const res = await API.get("/admin/portfolio");
      setPortfolio(res.data);
    } catch (err) {
      console.error("Portfolio Error:", err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  if (!portfolio)
    return (
      <div style={{ padding: 30, fontSize: 20 }}>
        Loading portfolio analytics…
      </div>
    );

  const approvalPieData = {
    labels: ["Approved", "Rejected", "Pending"],
    datasets: [
      {
        data: [
          portfolio.approvedLoans || 0,
          portfolio.rejectedLoans || 0,
          portfolio.pendingLoans || 0,
        ],
        backgroundColor: ["#22c55e", "#ef4444", "#3b82f6"],
      },
    ],
  };

  const monthlyLoanBarData = {
    labels: portfolio.months,
    datasets: [
      {
        label: "Loans Per Month",
        data: portfolio.monthlyCounts,
        backgroundColor: "#2563eb",
      },
    ],
  };

  const activeVsPendingTrend = {
    labels: portfolio.months,
    datasets: [
      {
        label: "Active Loans",
        data: portfolio.monthlyActive,
        borderColor: "#22c55e",
        backgroundColor: "rgba(34,197,94,0.2)",
        tension: 0.4,
      },
      {
        label: "Pending Loans",
        data: portfolio.monthlyPending,
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59,130,246,0.2)",
        tension: 0.4,
      },
    ],
  };

  return (
    <div style={{ background: "#f3f4f6", minHeight: "100vh" }}>
      <Navbar />

      <div style={{ display: "flex" }}>
        <Sidebar role="admin" />

        <main style={{ flex: 1, padding: 25 }}>
          <h1 style={{ fontSize: 30, fontWeight: 700, marginBottom: 20 }}>
            Portfolio Analytics
          </h1>

          {/* TOP CARDS */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: 20,
            }}
          >
            <div className="card">
              <h3>Total Users</h3>
              <p className="big-number">{portfolio.totalUsers}</p>
            </div>

            <div className="card">
              <h3>Pending Loans</h3>
              <p className="big-number">{portfolio.pendingLoans}</p>
            </div>

            <div className="card">
              <h3>Approved Loans</h3>
              <p className="big-number">{portfolio.approvedLoans}</p>
            </div>

            <div className="card">
              <h3>Rejected Loans</h3>
              <p className="big-number">{portfolio.rejectedLoans}</p>
            </div>
          </div>

          {/* PIE CHART */}
          <div className="card" style={{ marginTop: 30, padding: 20 }}>
            <h2>Loan Status Distribution</h2>
            <div style={{ width: 350, margin: "auto" }}>
              <Pie data={approvalPieData} />
            </div>
          </div>

          {/* BAR CHART */}
          <div className="card" style={{ marginTop: 30, padding: 20 }}>
            <h2>Monthly Loan Requests</h2>
            <Bar data={monthlyLoanBarData} />
          </div>

          {/* LINE CHART */}
          <div className="card" style={{ marginTop: 30, padding: 20 }}>
            <h2>Active vs Pending Trend</h2>
            <Line data={activeVsPendingTrend} />
          </div>
        </main>
      </div>
    </div>
  );
}
