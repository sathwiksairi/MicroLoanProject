import React, { useEffect, useState } from "react";
import API from "../../api/axiosConfig";
import Sidebar from "../../components/Sidebar.jsx";
import Navbar from "../../components/Navbar.jsx";

export default function AdminLogs() {
  const [logs, setLogs] = useState([]);

  const load = async () => {
    const res = await API.get("/admin/logs");
    setLogs(res.data);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div>
      <Navbar />
      <div style={{ display: "flex", gap: 24 }}>
        <Sidebar role="admin" />

        <main style={{ flex: 1, padding: 20 }}>
          <h1>Admin Activity Logs</h1>

          <table className="table" style={{ marginTop: 20 }}>
            <thead>
              <tr>
                <th>Admin</th>
                <th>Action</th>
                <th>Target</th>
                <th>Time</th>
              </tr>
            </thead>

            <tbody>
              {logs.map((log) => (
                <tr key={log._id}>
                  <td>{log.adminId?.name}</td>
                  <td>{log.action}</td>
                  <td>{log.targetUserId?.email}</td>
                  <td>{new Date(log.createdAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>

        </main>
      </div>
    </div>
  );
}
