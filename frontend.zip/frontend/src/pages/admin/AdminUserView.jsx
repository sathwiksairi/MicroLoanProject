import React, { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar.jsx";
import Navbar from "../../components/Navbar.jsx";
import API from "../../api/axiosConfig";
import { useParams } from "react-router-dom";

export default function AdminUserView() {
  const { userId } = useParams();
  const [data, setData] = useState(null);

  const load = async () => {
    const res = await API.get(`/admin/users/${userId}`);
    setData(res.data);
  };

  useEffect(() => {
    load();
  }, []);

  if (!data) return <div>Loading...</div>;

  const { user, loans } = data;

  return (
    <div>
      <Navbar />
      <div style={{ display: "flex", gap: 24 }}>
        <Sidebar role="admin" />

        <main style={{ flex: 1, padding: 20 }}>
          <div className="card">
            <h2>{user.name}</h2>
            <p>{user.email}</p>

            <p>
              <strong>Role:</strong> {user.role}
            </p>

            <p>
              <strong>KYC:</strong> {user.kyc?.status}
            </p>

            <p>
              <strong>Account:</strong> {user.accountStatus}
            </p>

            <p>
              <strong>Last Login:</strong>{" "}
              {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString() : "-"}
            </p>
          </div>

          <div className="card">
            <h3>Loan History</h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {loans.map((l) => (
                  <tr key={l._id}>
                    <td>{l.amount}</td>
                    <td>{l.status}</td>
                    <td>{new Date(l.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </main>
      </div>
    </div>
  );
}
