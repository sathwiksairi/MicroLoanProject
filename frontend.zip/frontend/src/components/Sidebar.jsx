// src/components/Sidebar.jsx
import React from "react";
import { NavLink } from "react-router-dom";

export default function Sidebar({ role = "user" }) {
  const linkClass = ({ isActive }) =>
    "sidebar-link" + (isActive ? " sidebar-link-active" : "");

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-title">MicroLoan</div>
        <div className="sidebar-subtitle">
          {role === "admin" ? "Admin Console" : "User Dashboard"}
        </div>
      </div>

      {/* USER MENU */}
      {role === "user" && (
        <nav className="sidebar-links">
          <NavLink to="/user/dashboard" className={linkClass}>
            Overview
          </NavLink>
          <NavLink to="/user/loans" className={linkClass}>
            Loans
          </NavLink>
          <NavLink to="/user/kyc" className={linkClass}>
            KYC
          </NavLink>
          <NavLink to="/user/wallet" className={linkClass}>
            Wallet
          </NavLink>
          {/* <NavLink to="/user/notifications" className={linkClass}>
            Notifications
          </NavLink> */}
          <NavLink to="/user/settings" className={linkClass}>
            Settings
          </NavLink>
        </nav>
      )}

      {/* ADMIN MENU */}
      {role === "admin" && (
        <nav className="sidebar-links">
          <NavLink to="/admin" className={linkClass}>
            Dashboard Overview
          </NavLink>
          <NavLink to="/admin/loans" className={linkClass}>
            Loan Requests
          </NavLink>
          <NavLink to="/admin/kyc" className={linkClass}>
            KYC Verification
          </NavLink>
          <NavLink to="/admin/users" className={linkClass}>
            Users Management
          </NavLink>
          <NavLink to="/admin/portfolio" className={linkClass}>
            Portfolio Analytics
          </NavLink>
        </nav>
      )}
    </aside>
  );
}
