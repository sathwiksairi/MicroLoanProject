// src/components/Navbar.jsx
import React from "react";

export default function Navbar({ user, onLogout }) {
  const initials = user?.name
    ? user.name
        .split(" ")
        .map((p) => p[0])
        .join("")
        .slice(0, 2)
        .toUpperCase()
    : "ML";

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="navbar-left">
          <div className="navbar-brand-main">MicroLoan</div>
          <span className="navbar-badge">Fintech Suite</span>
        </div>

        <div className="navbar-right">
          {user && (
            <div className="navbar-user">
              <div className="navbar-avatar">{initials}</div>
              <div style={{ display: "flex", flexDirection: "column" }}>
                <span style={{ fontSize: 13, fontWeight: 600 }}>
                  {user.name || "Admin"}
                </span>
                <span
                  style={{
                    fontSize: 11,
                    color: "#6b7280",
                    textTransform: "capitalize",
                  }}
                >
                  {user.role || "user"}
                </span>
              </div>
            </div>
          )}
          {onLogout && (
            <button className="btn btn-ghost" onClick={onLogout}>
              Logout
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
