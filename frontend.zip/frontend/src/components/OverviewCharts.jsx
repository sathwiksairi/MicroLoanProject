import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

export default function OverviewCharts({ data }) {
  // 🔥 prevent crash if API returned null / empty / undefined
  if (!data || !data.monthly) {
    return (
      <div className="card">
        <h3>Monthly Activity</h3>
        <p style={{ color: "#6b7280" }}>No data available yet.</p>
      </div>
    );
  }

  const chartData = {
    labels: data.monthly.map((m) => m.month),
    datasets: [
      {
        label: "Loan Amount",
        data: data.monthly.map((m) => m.amount),
        backgroundColor: "#3b82f6",
        borderRadius: 6,
      },
    ],
  };

  return (
    <div className="card">
      <h3>Monthly Activity</h3>
      <Bar data={chartData} />
    </div>
  );
}
