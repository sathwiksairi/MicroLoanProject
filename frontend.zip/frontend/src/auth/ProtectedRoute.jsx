// src/auth/ProtectedRoute.jsx
import React, { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "./AuthContext";

export default function ProtectedRoute({ allowed = [], children }) {
  const { user, loading } = useContext(AuthContext);

  if (loading) return <div style={{ padding: 20 }}>Loading...</div>;

  // Not logged in
  if (!user) return <Navigate to="/user-login" replace />;

  const userRole = user.role;

  // Role not allowed
  if (allowed.length > 0 && !allowed.includes(userRole)) {
    if (userRole === "admin") return <Navigate to="/admin" replace />;
    return <Navigate to="/user-dashboard" replace />;
  }

  return children;
}
