// frontend/src/auth/AuthContext.jsx
import React, { createContext, useEffect, useState } from "react";
import api from "../api/axiosConfig";

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUserState] = useState(() => {
    try {
      const raw = localStorage.getItem("ml_user");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(false);

  // central place to set token + user
  const setUser = (payload) => {
    if (!payload) {
      localStorage.removeItem("ml_token");
      localStorage.removeItem("ml_user");
      setUserState(null);
      return;
    }

    // backend auth returns { token, user }, but some places pass just user
    const token = payload.token || null;
    const u = payload.user ?? payload;

    if (token) localStorage.setItem("ml_token", token);
    localStorage.setItem("ml_user", JSON.stringify(u));
    setUserState(u);
  };

  const logout = () => setUser(null);

  // optional: registration helper (used by SignupPage)
  const register = async (name, email, password) => {
    const res = await api.post("/auth/register", { name, email, password });
    setUser(res.data); // { token, user }
    return res.data;
  };

  useEffect(() => {
    const token = localStorage.getItem("ml_token");
    if (!token) return;

    setLoading(true);
    (async () => {
      try {
        const res = await api.get("/users/me");
        const u = res.data.user ?? res.data;
        localStorage.setItem("ml_user", JSON.stringify(u));
        setUserState(u);
      } catch {
        localStorage.removeItem("ml_token");
        localStorage.removeItem("ml_user");
        setUserState(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, setUser, logout, loading, register }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
