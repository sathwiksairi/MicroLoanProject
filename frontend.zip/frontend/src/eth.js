// frontend/src/eth.js
import { ethers } from "ethers";
import tokenABI from "./contracts/MicroTokenAbi.json";
import poolABI from "./contracts/LendingPoolAbi.json";

// read from Vite env (set in .env)
const RPC_URL = import.meta.env.VITE_RPC_URL || "http://127.0.0.1:9545";
const tokenAddress = import.meta.env.VITE_TOKEN_ADDRESS;
const poolAddress = import.meta.env.VITE_POOL_ADDRESS;

/**
 * Create a read-only provider. Do NOT keep private keys in frontend.
 * If you must sign, ask user to connect MetaMask or provide server-side endpoints.
 */
export function getProvider() {
  return new ethers.JsonRpcProvider(RPC_URL);
}

export function getContracts(signerOrProvider) {
  const provider = signerOrProvider || getProvider();
  const token = new ethers.Contract(tokenAddress, tokenABI, provider);
  const pool = new ethers.Contract(poolAddress, poolABI, provider);
  return { token, pool };
}

export async function getTokenBalance(address) {
  const { token } = getContracts();
  const raw = await token.balanceOf(address);
  const human = ethers.formatUnits(raw, 18);
  return { human, symbol: "MTO" };
}
