export const basicAuthStyles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background:
      "linear-gradient(135deg, #2563EB 0%, #1E3A8A 40%, #0EA5E9 75%, #4338CA 100%)",
    backgroundSize: "300% 300%",
    animation: "gradientMove 16s ease infinite",
    padding: "20px",
  },

  card: {
    width: "100%",
    maxWidth: "430px",
    padding: "35px",
    borderRadius: "18px",
    background: "rgba(255,255,255,0.15)",
    backdropFilter: "blur(12px)",
    boxShadow: "0 8px 32px rgba(0,0,0,0.25)",
    textAlign: "center",
  },

  title: {
    fontSize: "26px",
    fontWeight: 700,
    marginBottom: "20px",
    color: "white",
  },

  field: { marginBottom: "14px" },

  input: {
    width: "100%",
    padding: "12px",
    borderRadius: "10px",
    border: "1px solid rgba(255,255,255,0.35)",
    background: "rgba(255,255,255,0.35)",
    color: "white",
    fontSize: "14px",
    outline: "none",
  },

  error: {
    color: "#fee2e2",
    fontSize: "13px",
    marginBottom: "10px",
  },

  primaryBtn: {
    width: "100%",
    padding: "12px",
    borderRadius: "10px",
    background: "#2563EB",
    color: "white",
    border: "none",
    fontSize: "15px",
    cursor: "pointer",
    marginTop: "10px",
    fontWeight: 600,
  },

  linkBtn: {
    marginTop: "10px",
    color: "#dbeafe",
    background: "transparent",
    border: "none",
    textDecoration: "underline",
    cursor: "pointer",
  },
};
