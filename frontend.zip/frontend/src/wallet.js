import { ethers } from "ethers";

const RPC_URL = "http://127.0.0.1:7545";  // Truffle / Ganache RPC

// Your Truffle private key
const PRIVATE_KEY = "ff888b096c541ca0ec32e145fac2d368a5095739640d8c209fd9f0b24b359df9";

export function getWallet() {
    const provider = new ethers.JsonRpcProvider(RPC_URL);
    const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
    return wallet;
}
