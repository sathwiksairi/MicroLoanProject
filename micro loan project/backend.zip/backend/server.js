import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./config/db.js";

// ROUTES
import authRoutes from "./routes/authRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import loanRoutes from "./routes/loanRoutes.js";

import adminRoutes from "./routes/adminRoutes.js";
import adminUserRoutes from "./routes/adminUserRoutes.js";
import adminPortfolioRoutes from "./routes/adminPortfolioRoutes.js";
import adminAuditRoutes from "./routes/adminAuditRoutes.js";
import adminSummaryRoutes from "./routes/adminSummaryRoutes.js";

dotenv.config();

// CONNECT DATABASE
connectDB();

const app = express();

// MIDDLEWARES
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// ROOT CHECK
app.get("/", (req, res) => {
  res.send("MicroLoan API is running...");
});

// PUBLIC ROUTES
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/loans", loanRoutes);

// ADMIN MAIN (loans + kyc)
app.use("/api/admin", adminRoutes);

// ADMIN — USERS MANAGEMENT
app.use("/api/admin/users", adminUserRoutes);

// ADMIN — PORTFOLIO ANALYTICS
app.use("/api/admin/portfolio", adminPortfolioRoutes);

// ADMIN — SUMMARY DASHBOARD
app.use("/api/admin/summary", adminSummaryRoutes);

// ADMIN — ACTIVITY LOGS
app.use("/api/admin/logs", adminAuditRoutes);

// GLOBAL ERROR HANDLER
app.use((err, req, res, next) => {
  console.error("Error:", err.message);

  res.status(res.statusCode || 500).json({
    message: err.message,
    stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
  });
});

// START SERVER
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`✔ Server running on http://localhost:${PORT}`)
);
