// backend/models/User.js
import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true },

    role: { type: String, default: "user", enum: ["user", "admin"] },

    // KYC info
    kyc: {
      status: {
        type: String,
        default: "not_submitted",
        enum: ["not_submitted", "pending", "verified", "rejected"],
      },
      cryptoAddress: String,
      verifiedAt: Date,
    },

    walletBalance: { type: Number, default: 0 },

    // NEW: bank-style status & tracking
    accountStatus: {
      type: String,
      enum: ["active", "frozen", "blocked"],
      default: "active",
    },
    lastLoginAt: { type: Date },
  },
  { timestamps: true }
);

export default mongoose.model("User", userSchema);