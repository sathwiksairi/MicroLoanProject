// backend/models/Loan.js
import mongoose from "mongoose";

const loanSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },

  amount: {
    type: Number,
    required: true,
  },

  // Tenure in days
  tenureDays: {
    type: Number,
    required: true,
  },

  status: {
    type: String,
    enum: ["pending", "approved", "rejected", "repaid"],
    default: "pending",
  },

  // Request date (used as "Req" column in UI)
  createdAt: {
    type: Date,
    default: Date.now,
  },

  // When user should repay
  repayBy: {
    type: Date,
  },

  // Admin timestamps / notes
  approvedAt: Date,
  rejectedAt: Date,
  repaidAt: Date,
  adminNote: String,
});

const Loan = mongoose.model("Loan", loanSchema);
export default Loan;
