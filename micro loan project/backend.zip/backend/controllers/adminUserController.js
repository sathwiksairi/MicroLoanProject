import User from "../models/User.js";
import Loan from "../models/Loan.js";
import { logAction } from "./adminAuditController.js";

export const getAllUsersAdmin = async (req, res) => {
  const users = await User.find().select("-password");
  res.json(users);
};

export const getUserDetailsAdmin = async (req, res) => {
  const user = await User.findById(req.params.userId).select("-password");
  const loans = await Loan.find({ user: req.params.userId });
  res.json({ user, loans });
};

export const updateUserStatus = async (req, res) => {
  const { accountStatus } = req.body;
  const user = await User.findById(req.params.userId);
  user.accountStatus = accountStatus;
  await user.save();

  await logAction(
    req.user._id,
    `Set status to ${accountStatus}`,
    user._id,
    {},
    req.ip
  );

  res.json({ message: "Status updated", user });
};

export const updateUserRole = async (req, res) => {
  const { role } = req.body;
  const user = await User.findById(req.params.userId);
  user.role = role;
  await user.save();

  await logAction(
    req.user._id,
    `Changed role to ${role}`,
    user._id,
    {},
    req.ip
  );

  res.json({ message: "Role updated", user });
};
