import AdminLog from "../models/AdminLog.js";

export const logAction = async (adminId, action, targetUserId, details, ip) => {
  try {
    await AdminLog.create({
      adminId,
      action,
      targetUserId,
      details,
      ip,
    });
  } catch (err) {
    console.error("Error writing AdminLog:", err);
  }
};

export const getAdminLogs = async (req, res) => {
  const logs = await AdminLog.find()
    .populate("adminId", "name email")
    .populate("targetUserId", "name email")
    .sort({ createdAt: -1 });

  res.json(logs);
};
