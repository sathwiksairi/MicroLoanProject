import User from "../models/User.js";
import Loan from "../models/Loan.js";

export const getAdminSummary = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const kycPending = await User.countDocuments({ "kyc.status": "pending" });

    // FIXED: count all pending-like statuses
    const loansPending = await Loan.countDocuments({
      status: { $regex: /pending|review|process|wait/i }
    });

    const activeLoans = await Loan.countDocuments({
      status: { $regex: /^approved$/i }
    });

    const recentUsers = await User.find()
      .select("name email createdAt")
      .sort({ createdAt: -1 })
      .limit(5);

    return res.json({
      totalUsers,
      kycPending,
      loansPending,
      activeLoans,
      recentUsers: recentUsers || [],
    });
  } catch (err) {
    console.error("Summary Error:", err);
    return res.json({
      totalUsers: 0,
      kycPending: 0,
      loansPending: 0,
      activeLoans: 0,
      recentUsers: [],
    });
  }
};
