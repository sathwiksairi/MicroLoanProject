// backend/controllers/adminController.js
import asyncHandler from "express-async-handler";
import Loan from "../models/Loan.js";

// GET /api/admin/loans
export const getAllLoans = asyncHandler(async (req, res) => {
  const loans = await Loan.find()
    .populate("user", "name email")
    .sort({ createdAt: -1 });
  res.json(loans);
});

// PATCH /api/admin/loans/:id/approve
export const approveLoan = asyncHandler(async (req, res) => {
  const loan = await Loan.findById(req.params.id);
  if (!loan) {
    res.status(404);
    throw new Error("Loan not found");
  }

  loan.status = "approved";
  loan.approvedAt = new Date();
  loan.adminNote = req.body.remarks || loan.adminNote;
  await loan.save();

  res.json({ message: "Loan approved", loan });
});

// PATCH /api/admin/loans/:id/reject
export const rejectLoan = asyncHandler(async (req, res) => {
  const loan = await Loan.findById(req.params.id);
  if (!loan) {
    res.status(404);
    throw new Error("Loan not found");
  }

  loan.status = "rejected";
  loan.rejectedAt = new Date();
  loan.adminNote = req.body.remarks || loan.adminNote;
  await loan.save();

  res.json({ message: "Loan rejected", loan });
});
