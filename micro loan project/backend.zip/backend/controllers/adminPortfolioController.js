// backend/controllers/adminPortfolioController.js
import User from "../models/User.js";
import Loan from "../models/Loan.js";

export const getPortfolioAnalytics = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();

    const pendingLoans = await Loan.countDocuments({ status: "pending" });
    const approvedLoans = await Loan.countDocuments({ status: "approved" });
    const rejectedLoans = await Loan.countDocuments({ status: "rejected" });

    const loans = await Loan.find().sort({ createdAt: 1 });

    const months = [];
    const monthlyCounts = [];
    const monthlyActive = [];
    const monthlyPending = [];

    loans.forEach((loan) => {
      const month = new Date(loan.createdAt).toLocaleString("default", {
        month: "short",
      });

      if (!months.includes(month)) {
        months.push(month);
        monthlyCounts.push(0);
        monthlyActive.push(0);
        monthlyPending.push(0);
      }

      const idx = months.indexOf(month);
      monthlyCounts[idx]++;

      if (loan.status === "approved") monthlyActive[idx]++;
      if (loan.status === "pending") monthlyPending[idx]++;
    });

    res.json({
      totalUsers,
      pendingLoans,
      approvedLoans,
      rejectedLoans,
      months,
      monthlyCounts,
      monthlyActive,
      monthlyPending,
    });
  } catch (err) {
    console.error("Portfolio Error:", err);
    res.json({
      totalUsers: 0,
      pendingLoans: 0,
      approvedLoans: 0,
      rejectedLoans: 0,
      months: [],
      monthlyCounts: [],
      monthlyActive: [],
      monthlyPending: [],
    });
  }
};
