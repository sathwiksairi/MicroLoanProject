// backend/controllers/userController.js
import asyncHandler from "express-async-handler";
import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// Helper to create token
const createToken = (id) => {
  return jwt.sign(
    { id },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
};

// =========================
// REGISTER USER
// =========================
export const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Please include all fields");
  }

  const existing = await User.findOne({ email });
  if (existing) {
    res.status(400);
    throw new Error("User already exists");
  }

  const hashed = await bcrypt.hash(password, 10);

  const user = await User.create({
    name,
    email,
    password: hashed,
    role: "user",
    kyc: { status: "not_submitted" }
  });

  res.status(201).json({
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    token: createToken(user._id),
  });
});

// =========================
// LOGIN USER
// =========================
export const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await bcrypt.compare(password, user.password))) {
    user.lastLoginAt = new Date();
    await user.save();

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: createToken(user._id),
    });
  } else {
    res.status(401);
    throw new Error("Invalid credentials");
  }
});

// =========================
// GET LOGGED-IN USER
// =========================
export const getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select("-password");

  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  res.json(user);
});

// =========================
// UPDATE KYC (NEW CRYPTO FLOW)
// =========================
export const updateKyc = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  const {
    fullName,
    dob,
    gender,
    phone,
    email,
    panNumber,
    aadhaarNumber,
    passportNumber,
    walletAddress,     // NEW: crypto wallet
    addressLine1,
    addressLine2,
    city,
    state,
    postalCode
  } = req.body;

  // Merge new KYC data
  user.kyc = {
    status: "pending",
    verifiedAt: undefined,

    personal: {
      fullName: fullName || user.kyc?.personal?.fullName,
      dob: dob || user.kyc?.personal?.dob,
      gender: gender || user.kyc?.personal?.gender,
      phone: phone || user.kyc?.personal?.phone,
      email: email || user.kyc?.personal?.email,
    },

    documents: {
      panNumber: panNumber || user.kyc?.documents?.panNumber,
      aadhaarNumber: aadhaarNumber || user.kyc?.documents?.aadhaarNumber,
      passportNumber: passportNumber || user.kyc?.documents?.passportNumber,
    },

    crypto: {
      walletAddress: walletAddress || user.kyc?.crypto?.walletAddress,
    },

    address: {
      addressLine1: addressLine1 || user.kyc?.address?.addressLine1,
      addressLine2: addressLine2 || user.kyc?.address?.addressLine2,
      city: city || user.kyc?.address?.city,
      state: state || user.kyc?.address?.state,
      postalCode: postalCode || user.kyc?.address?.postalCode,
    }
  };

  await user.save();

  res.json({
    message: "KYC submitted successfully",
    kyc: user.kyc,
  });
});
