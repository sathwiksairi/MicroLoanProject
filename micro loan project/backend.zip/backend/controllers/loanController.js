// backend/controllers/loanController.js
import Loan from "../models/Loan.js";
import User from "../models/User.js";

// POST /api/loans/request
export const createLoan = async (req, res, next) => {
  try {
    const { amount, tenureDays } = req.body;

    if (!amount || !tenureDays) {
      return res
        .status(400)
        .json({ message: "Amount and tenureDays are required" });
    }

    const days = Number(tenureDays);
    if (Number.isNaN(days) || days <= 0) {
      return res
        .status(400)
        .json({ message: "tenureDays must be a positive number" });
    }

    const repayBy = new Date();
    repayBy.setDate(repayBy.getDate() + days);

    const loan = await Loan.create({
      user: req.user._id,
      amount: Number(amount),
      tenureDays: days,
      repayBy,
      status: "pending",
    });

    return res.status(201).json(loan);
  } catch (err) {
    console.error("Create loan error:", err);
    next(err);
  }
};

// GET /api/loans/my-loans
export const getUserLoans = async (req, res, next) => {
  try {
    const loans = await Loan.find({ user: req.user._id }).sort({
      createdAt: -1,
    });
    return res.json(loans);
  } catch (err) {
    console.error("Get user loans error:", err);
    next(err);
  }
};

// PATCH /api/loans/:id/repay
export const repayLoan = async (req, res, next) => {
  try {
    const { id } = req.params;

    const loan = await Loan.findOne({ _id: id, user: req.user._id });
    if (!loan) {
      return res.status(404).json({ message: "Loan not found" });
    }

    if (loan.status !== "approved") {
      return res
        .status(400)
        .json({ message: "Only approved loans can be repaid" });
    }

    loan.status = "repaid";
    loan.repaidAt = new Date();
    await loan.save();

    return res.json({ message: "Loan repaid", loan });
  } catch (err) {
    console.error("Repay loan error:", err);
    next(err);
  }
};
