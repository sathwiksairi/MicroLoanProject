import express from "express";
import { protect, admin } from "../middleware/authMiddleware.js";
import { getAdminLogs } from "../controllers/adminAuditController.js";

const router = express.Router();

router.get("/", protect, admin, getAdminLogs);

export default router;
