// backend/routes/adminRoutes.js
import express from "express";
import {
  approveLoan,
  rejectLoan,
  getAllLoans,
} from "../controllers/adminController.js";
import { protect, admin } from "../middleware/authMiddleware.js";

const router = express.Router();

// Loans for admin
router.get("/loans", protect, admin, getAllLoans);
router.patch("/loans/:id/approve", protect, admin, approveLoan);
router.patch("/loans/:id/reject", protect, admin, rejectLoan);

export default router;
