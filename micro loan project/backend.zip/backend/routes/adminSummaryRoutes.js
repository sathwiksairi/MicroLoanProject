import express from "express";
import { protect, admin } from "../middleware/authMiddleware.js";
import { getAdminSummary } from "../controllers/adminSummaryController.js";

const router = express.Router();

router.get("/", protect, admin, getAdminSummary);

export default router;
