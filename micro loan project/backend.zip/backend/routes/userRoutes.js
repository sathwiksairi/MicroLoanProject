// backend/routes/userRoutes.js
import express from "express";
import {
  registerUser,
  loginUser,
  getMe,
  updateKyc
} from "../controllers/userController.js";

import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// PUBLIC AUTH ROUTES
router.post("/register", registerUser);
router.post("/login", loginUser);

// USER PROFILE (PROTECTED)
router.get("/me", protect, getMe);

// KYC SUBMISSION (PROTECTED)
router.put("/kyc", protect, updateKyc);

// OPTIONAL: GET KYC DETAILS
router.get("/kyc", protect, (req, res) => {
  res.json(req.user.kyc || {});
});

export default router;
