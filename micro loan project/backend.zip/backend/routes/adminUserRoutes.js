import express from "express";
import { protect, admin } from "../middleware/authMiddleware.js";
import {
  getAllUsersAdmin,
  getUserDetailsAdmin,
  updateUserStatus,
  updateUserRole,
} from "../controllers/adminUserController.js";

const router = express.Router();

router.get("/", protect, admin, getAllUsersAdmin);
router.get("/:userId", protect, admin, getUserDetailsAdmin);
router.patch("/:userId/status", protect, admin, updateUserStatus);
router.patch("/:userId/role", protect, admin, updateUserRole);

export default router;
