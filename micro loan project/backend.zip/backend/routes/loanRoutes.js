// backend/routes/loanRoutes.js
import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import {
  createLoan,
  getUserLoans,
  repayLoan,
} from "../controllers/loanController.js";

const router = express.Router();

// User loan actions
router.post("/request", protect, createLoan);
router.get("/my-loans", protect, getUserLoans);
router.patch("/:id/repay", protect, repayLoan);

export default router;
