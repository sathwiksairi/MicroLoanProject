// backend/routes/adminPortfolioRoutes.js
import express from "express";
import { protect, admin } from "../middleware/authMiddleware.js";
import { getPortfolioAnalytics } from "../controllers/adminPortfolioController.js";

const router = express.Router();

router.get("/", protect, admin, getPortfolioAnalytics);

export default router;
