// backend/config/blockchain.js
import { ethers } from "ethers";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MicroTokenAbi = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../contracts/MicroTokenAbi.json"))
);

const LendingPoolAbi = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../contracts/LendingPoolAbi.json"))
);

const RPC_URL = "http://127.0.0.1:9545";
const PRIVATE_KEY =
  "ff888b096c541ca0ec32e145fac2d368a5095739640d8c209fd9f0b24b359df9";

const TOKEN_ADDRESS = "0x835e170560843cEF3Fc1EfF2a28f1B1282537319";
const POOL_ADDRESS = "0xBEcc937b21CC37a0A61EB322Edf62438B8cEdAB3";

const provider = new ethers.JsonRpcProvider(RPC_URL);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

export const tokenContract = new ethers.Contract(
  TOKEN_ADDRESS,
  MicroTokenAbi,
  wallet
);

export const poolContract = new ethers.Contract(
  POOL_ADDRESS,
  LendingPoolAbi,
  wallet
);
